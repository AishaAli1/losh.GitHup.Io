
* Object:

In this project, a map of Riyadh was built, Five malls were shown on the map

* How the map works:

1- You need your device

2- After open, the site by (index.html) can be viewed to malls by clicking on Show Listings

3- Then click on marker you can read more information about the site

4- you can transfer to Wikipedia page

5- You can search for a specific location

* Project contents:

1- index.html

2- main.js

3- style.css

4- README.md

* API: 

1. Wikipedia 
2. Google Map

* Resource(s): 

1. Udacity Course (https://classroom.udacity.com/nanodegrees/nd001/parts/00113454014/modules/271165859175460/lessons/3310298553/concepts/31621285920923)
2. Google Map
3. KnockoutJS
4. Ajax


